import React from 'react';
import './App.css';
import Navbar from './Navbar';

class App extends React.Component {
  render(){
    return(
      <Navbar/>
    );
  }
}

  export default App;